<div class="row">
    <?php echo $records->render(); ?>

</div>
<?php /**PATH C:\xampp\htdocs\adminlte-generator\vendor\infyomlabs\adminlte-templates\src/../views/common/paginate.blade.php ENDPATH**/ ?>