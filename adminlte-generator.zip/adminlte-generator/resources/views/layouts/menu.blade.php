




<li class="{{ Request::is('quotes*') ? 'active' : '' }}">
    <a href="{{ route('quotes.index') }}"><i class="fa fa-edit"></i><span>Quotes</span></a>
</li>

<li class="{{ Request::is('tags*') ? 'active' : '' }}">
    <a href="{{ route('tags.index') }}"><i class="fa fa-edit"></i><span>Tags</span></a>
</li>

