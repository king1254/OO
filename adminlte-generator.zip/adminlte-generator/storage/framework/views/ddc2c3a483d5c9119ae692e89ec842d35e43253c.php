




<li class="<?php echo e(Request::is('quotes*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('quotes.index')); ?>"><i class="fa fa-edit"></i><span>Quotes</span></a>
</li>

<li class="<?php echo e(Request::is('tags*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('tags.index')); ?>"><i class="fa fa-edit"></i><span>Tags</span></a>
</li>

<?php /**PATH C:\xampp\htdocs\adminlte-generator\resources\views/layouts/menu.blade.php ENDPATH**/ ?>