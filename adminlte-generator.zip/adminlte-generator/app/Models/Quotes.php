<?php

namespace App\Models;

use Eloquent as Model;

/**
 * Class Quotes
 * @package App\Models
 * @version July 7, 2020, 11:58 am UTC
 *
 * @property string $Tilte
 */
class Quotes extends Model
{

    public $table = 'Quotes';
    



    public $fillable = [
        'Tilte'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'Tilte' => 'string'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        
    ];

    
}
