<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateStringsTable extends Migration
{

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('Strings', function (Blueprint $table) {
            $table->increments('id');
            $table->text('PRIVACYPOLICY');
            $table->text('TERMSSERVICE');
            $table->text('ABOUTUS');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('Strings');
    }
}
