<?php

namespace App\Repositories;

use App\Models\Quotes;
use App\Repositories\BaseRepository;

/**
 * Class QuotesRepository
 * @package App\Repositories
 * @version July 7, 2020, 11:58 am UTC
*/

class QuotesRepository extends BaseRepository
{
    /**
     * @var array
     */
    protected $fieldSearchable = [
        'Tilte'
    ];

    /**
     * Return searchable fields
     *
     * @return array
     */
    public function getFieldsSearchable()
    {
        return $this->fieldSearchable;
    }

    /**
     * Configure the Model
     **/
    public function model()
    {
        return Quotes::class;
    }
}
