<!-- Tilte Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('Tilte', 'Tilte:'); ?>

    <?php echo Form::text('Tilte', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('quotes.index')); ?>" class="btn btn-default">Cancel</a>
</div>
<?php /**PATH C:\xampp\htdocs\adminlte-generator\resources\views/quotes/fields.blade.php ENDPATH**/ ?>