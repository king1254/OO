<?php

namespace App\Models;

use Eloquent as Model;

/**
 * Class Tags
 * @package App\Models
 * @version July 7, 2020, 12:00 pm UTC
 *
 * @property string $Tilte
 */
class Tags extends Model
{

    public $table = 'Tags';
    



    public $fillable = [
        'Tilte'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'Tilte' => 'string'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        
    ];

    
}
