<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{{ $tags->id }}</p>
</div>

<!-- Tilte Field -->
<div class="form-group">
    {!! Form::label('Tilte', 'Tilte:') !!}
    <p>{{ $tags->Tilte }}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{{ $tags->created_at }}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{{ $tags->updated_at }}</p>
</div>

