<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{{ $quotes->id }}</p>
</div>

<!-- Tilte Field -->
<div class="form-group">
    {!! Form::label('Tilte', 'Tilte:') !!}
    <p>{{ $quotes->Tilte }}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{{ $quotes->created_at }}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{{ $quotes->updated_at }}</p>
</div>

